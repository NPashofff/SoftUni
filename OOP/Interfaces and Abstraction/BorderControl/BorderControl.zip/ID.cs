﻿namespace BorderControl
{
    public abstract class ID
    {
        public ID(string id)
        {
            Id = id;
        }
        public string Id { get;}
    }
}
