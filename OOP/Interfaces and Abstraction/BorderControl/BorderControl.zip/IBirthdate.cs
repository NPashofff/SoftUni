﻿namespace BorderControl
{
    interface IBirthdate
    {
        public string Birthdate { get;}
    }
}
