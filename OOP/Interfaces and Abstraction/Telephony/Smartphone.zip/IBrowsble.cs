﻿namespace Telephony
{
    public interface IBrowsble
    {
        public string Browse(string url);
    }
}
