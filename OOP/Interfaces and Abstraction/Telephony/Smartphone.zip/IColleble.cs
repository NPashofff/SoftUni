﻿namespace Telephony
{
    public interface ICallble
    {
        public string Call(string num);
    }
}
